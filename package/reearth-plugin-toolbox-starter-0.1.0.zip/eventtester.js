(function(){"use strict";var e=`<style type="text/css">
html,body{margin:0;overflow:hidden;font-family:Noto Sans,Arial,sans-serif;font-size:14px}*{box-sizing:border-box}

</style>
<script type="module">
//assets/index.f5b4867d.js
const p=function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))o(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const s of r.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&o(s)}).observe(document,{childList:!0,subtree:!0});function i(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerpolicy&&(r.referrerPolicy=e.referrerpolicy),e.crossorigin==="use-credentials"?r.credentials="include":e.crossorigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function o(e){if(e.ep)return;e.ep=!0;const r=i(e);fetch(e.href,r)}};p();var l={},d=window.ReactDOM;l.createRoot=d.createRoot,l.hydrateRoot=d.hydrateRoot;var u={exports:{}},c={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var m=window.React,y=Symbol.for("react.element"),v=Symbol.for("react.fragment"),R=Object.prototype.hasOwnProperty,_=m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,h={key:!0,ref:!0,__self:!0,__source:!0};function f(n,t,i){var o,e={},r=null,s=null;i!==void 0&&(r=""+i),t.key!==void 0&&(r=""+t.key),t.ref!==void 0&&(s=t.ref);for(o in t)R.call(t,o)&&!h.hasOwnProperty(o)&&(e[o]=t[o]);if(n&&n.defaultProps)for(o in t=n.defaultProps,t)e[o]===void 0&&(e[o]=t[o]);return{$$typeof:y,type:n,key:r,ref:s,props:e,_owner:_.current}}c.Fragment=v;c.jsx=f;c.jsxs=f;u.exports=c;const a=u.exports.jsx,w=window.React.useCallback,O=window.React.useEffect,g=()=>{const n=w(()=>{globalThis.addEventListener("message",t=>{t.source!==globalThis.parent||!t.data.act||t.data.act==="mousemove"&&console.log("mousemove")})},[]);return O(()=>{n()},[n]),a("div",{children:"Event Tester"})},E=window.React;l.createRoot(document.getElementById("root")).render(a(E.StrictMode,{children:a(g,{})}));

<\/script>
<title></title>
<script src="https://cdn.jsdelivr.net/npm/react@18.1.0/umd/react.production.min.js"><\/script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18.1.0/umd/react-dom.production.min.js"><\/script>
<div id="root"></div>


`;globalThis.reearth.ui.show(e,{width:312,height:46}),globalThis.reearth.on("mousemove",t=>{globalThis.reearth.ui.postMessage({act:"mousemove",payload:t})})})();
