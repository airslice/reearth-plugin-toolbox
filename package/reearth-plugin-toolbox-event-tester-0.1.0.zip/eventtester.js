(function(){"use strict";var e=`<style type="text/css">
html,body{margin:0;overflow:hidden;font-family:Noto Sans,Arial,sans-serif;font-size:14px}*{box-sizing:border-box}

</style>
<script type="module">
//assets/index.41ac9525.js
const p=function(){const r=document.createElement("link").relList;if(r&&r.supports&&r.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))o(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const i of t.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&o(i)}).observe(document,{childList:!0,subtree:!0});function s(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerpolicy&&(t.referrerPolicy=e.referrerpolicy),e.crossorigin==="use-credentials"?t.credentials="include":e.crossorigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function o(e){if(e.ep)return;e.ep=!0;const t=s(e);fetch(e.href,t)}};p();var l={},d=window.ReactDOM;l.createRoot=d.createRoot,l.hydrateRoot=d.hydrateRoot;var f={exports:{}},c={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var m=window.React,y=Symbol.for("react.element"),v=Symbol.for("react.fragment"),_=Object.prototype.hasOwnProperty,R=m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,h={key:!0,ref:!0,__self:!0,__source:!0};function u(n,r,s){var o,e={},t=null,i=null;s!==void 0&&(t=""+s),r.key!==void 0&&(t=""+r.key),r.ref!==void 0&&(i=r.ref);for(o in r)_.call(r,o)&&!h.hasOwnProperty(o)&&(e[o]=r[o]);if(n&&n.defaultProps)for(o in r=n.defaultProps,r)e[o]===void 0&&(e[o]=r[o]);return{$$typeof:y,type:n,key:t,ref:i,props:e,_owner:R.current}}c.Fragment=v;c.jsx=u;c.jsxs=u;f.exports=c;const a=f.exports.jsx,w=window.React.useEffect,O=()=>(w(()=>{globalThis.addEventListener("message",n=>{n.source!==globalThis.parent||!n.data.act||n.data.act==="mousemove"&&console.log("mousemove")})},[]),a("div",{children:"Event Tester"})),g=window.React;l.createRoot(document.getElementById("root")).render(a(g.StrictMode,{children:a(O,{})}));

<\/script>
<title></title>
<script src="https://cdn.jsdelivr.net/npm/react@18.1.0/umd/react.production.min.js"><\/script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18.1.0/umd/react-dom.production.min.js"><\/script>
<div id="root"></div>


`;globalThis.reearth.ui.show(e,{width:312,height:46}),globalThis.reearth.on("mousemove",t=>{globalThis.reearth.ui.postMessage({act:"mousemove",payload:t})})})();
