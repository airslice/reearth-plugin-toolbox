# Layer Exporter

This is a Re:earth plugin made with [reearth-plugin-toolbox](https://github.com/airslice/reearth-plugin-toolbox).

Export layers data.

![test reearth dev_published html_alias=dbajbgegie(1440 desktop) (1)](https://user-images.githubusercontent.com/21994748/183613180-3a4050d5-9627-41b3-9368-cc72c6b98812.png)

<img width="1383" alt="WX20220809-171914@2x" src="https://user-images.githubusercontent.com/21994748/183613199-4bb42074-1fdd-43e5-b228-8130fbd496d5.png">

- Features:
  - Currently support .csv only.
  - Contains `title` `lat` `lng` by default;
