# Layer Exporter

This is a Re:earth plugin made with [reearth-plugin-toolbox](https://github.com/airslice/reearth-plugin-toolbox).

Export layers data.

- Features:
  - Currently support .csv only.
  - Contains `title` `lat` `lng` by default;