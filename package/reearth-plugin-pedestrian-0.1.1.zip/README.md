# Pedestrian

This is a Re:earth plugin made with [reearth-plugin-toolbox](https://github.com/airslice/reearth-plugin-toolbox).

Provide a pedestrian mode to explore the earth.

![test reearth dev_edit_01ga8azxqp3yas5f02dgczpwgx_preview(1440 desktop)](https://user-images.githubusercontent.com/21994748/190207733-7045f568-9a33-43be-98e3-8561dc015e5a.png)


- Features:
  - Support mouse & keyboard to control the camera.

- Notice:
  - Please turn on `Terrain` and `Hide objects under terrain` in `Scene` panel.