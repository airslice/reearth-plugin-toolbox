# Screen Save

This is a Re:earth plugin made with [reearth-plugin-toolbox](https://github.com/airslice/reearth-plugin-toolbox).

Capture current map and download the image.

![test reearth dev_edit_01gm7f13vzhkrdjf0pq0dw7r98_preview(1440 desktop)](https://user-images.githubusercontent.com/21994748/207515171-46771629-d3cc-4aba-8e7b-a480c08f3ec7.png)


- Note:
  - Currently save the image as PNG.
  - Only capture the earth canvas content.
  - Please use other tools if you want to capture the image with UI like infobox.
