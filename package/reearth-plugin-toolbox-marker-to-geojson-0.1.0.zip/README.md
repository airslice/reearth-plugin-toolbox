# Marker to GeoJSON

This is a Re:earth plugin made with [reearth-plugin-toolbox](https://github.com/airslice/reearth-plugin-toolbox).

Export Re:Earth classic marker data to GeoJSON format.
